package com.javacodegeeks;

public class MyClass {

    
}
